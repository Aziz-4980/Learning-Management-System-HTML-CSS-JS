<?php
    $con =  new mysqli("localhost","root","","upload");
    if(isset($_POST['save']))
    {
        $filename = $_FILES['myfile']['name'];
        $dest = 'upload/' .$filename;
        $extenstion = pathinfo($filename,PATHINFO_EXTENSION);
        $file = $_FILES['myfile']['tmp_name'];
        $size = $_FILES['myfile']['size'];
        if(!in_array($extenstion, ['zip', 'pdf']))
        {
            echo "You can only upload zip, pdf!";
        }
        else {
            if(move_uploaded_file($file, $dest))
            {
                $sql = "INSERT INTO uploadfile (lecturefileName,size,downloads) VALUES('$filename', '$size', 0)";
                if (mysqli_query($con,$sql))
                {
                    echo "file uploaded succesfully";
                }
                else
                {
                    echo "Failed to upload file";
                }
            }
        }
    }

?>