<?php
    $con =  new mysqli("localhost","root","","upload");
    $sql = "SELECT * from uploadfile";
    $result = mysqli_query($con, $sql) or die( mysqli_error($con));
    $files = mysqli_fetch_all($result,MYSQLI_ASSOC);
    if(isset($_POST['save']))
    {
        $filename = $_FILES['myfile']['name'];
        $dest = 'upload/' .$filename;
        $extenstion = pathinfo($filename,PATHINFO_EXTENSION);
        $file = $_FILES['myfile']['tmp_name'];
        $size = $_FILES['myfile']['size'];
        if(!in_array($extenstion, ['zip', 'pdf']))
        {
            echo "You can only upload zip, pdf!";
        }
        else {
            if(move_uploaded_file($file, $dest))
            {
                $sql = "INSERT INTO uploadfile (lecturefileName,size,downloads) VALUES('$filename', '$size', 0)";
                if (mysqli_query($con,$sql))
                {
                    echo "file uploaded succesfully";
                }
                else
                {
                    echo "Failed to upload file";
                }
            }
        }
    }
    if(isset($_GET['file_id']))
    {
        $id = $_GET['file_id'];
        $sql = "SELECT * FROM uploadfile WHERE id = $id";
        $result = mysqli_query($con, $sql) or die( mysqli_error($con));
        $file = mysqli_fetch_assoc($result);
        $filepath = 'upload/' .$file['lecturefileName'];

        if(file_exists($filepath))
        {
            header('Content-Type: application/octet-stream');

            header('Content-Description: File-Transfer');

            header('Content-Disposition: attachement; filename=' . basename($filepath));

            header('Expires : 0');

            header('Cache-Control: must-revalidate');

            header('Pragma: Public');

            header('Content-Length:' .filesize('upload/' . $file['lecturefileName']));

            readfile('upload/' . $file['lecturefileName']);

            $newCount = $file['downloads'] +1;
            $updatQuery = "UPDATE uploadfile SET downloads= $newCount WHERE id =$id";
            mysqli_query($con,$updatQuery);
            exit;
        }
    }

?>