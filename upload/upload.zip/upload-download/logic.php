<?php
    $con =  new mysqli("localhost","root","","upload");
    if(isset($_POST['save']))
    {
        $filename = $_FILES['myfile']['lecturefileName'];
        $dest = 'uploads/' .$filename;
        $extenstion = pathinfo($filename,PATHINFO_EXTENSION);
        $file = $_FILES['myfile']['tmp'];
        if(!in_array($extenstion, ['zip', 'pdf', 'doc', 'ppt']))
        {
            echo "Invalid Format of File. You can only upload zip, pdf, doc or ppt!";
        }
        else {
            if(move_uploaded_file($file, $destination))
            {
                $sql = "INSERT INTO upload (lecturename,size,downloads) VALUES('$filename', '$size', 0)";
                if (mysqli_query($con,$sql))
                {
                    echo "file uploaded succesfully";
                }
                else
                {
                    echo "Failed to upload file";
                }
            }
        }
    }

?>