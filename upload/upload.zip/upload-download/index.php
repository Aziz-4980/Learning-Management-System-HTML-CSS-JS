<?php include 'logic.php'?>
<!DOCTYPE html>
<html>
    <head>
        <title>upload</title>
        </head>
    <body>
        <div class="container">
            <div class="row">
                <form action="index.php" method="POST" enctype="multipart/form-data">
                    <h3>Upload Files</h3>
                    <input type="file" name="myfile"><br>
                    <button type="submit" name="save">Upload</button>
                </form>
            </div>
        </div>
</body>
</html>